#include <iostream>

int main(int argc, char **argv)
{
	int M,C;
	FILE (*ent,*sal);
	fopen("pista.in",%d);
	
	
	return 0;
}

