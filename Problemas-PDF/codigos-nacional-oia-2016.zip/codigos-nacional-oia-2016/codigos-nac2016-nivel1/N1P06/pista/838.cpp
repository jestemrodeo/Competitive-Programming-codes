#include <iostream>


using namespace std;



int main(){

DISCULPEN, NO PUDE HACER NADA, NO ENTENDI;

return 0;
}
