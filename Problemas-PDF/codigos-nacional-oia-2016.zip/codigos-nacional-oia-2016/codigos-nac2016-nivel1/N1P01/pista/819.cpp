#include <bits/stdc++.h>
using namespace std;
int main (){
	ifstream ent("pista.in");
	ofstream sal("pista.out");
	int m,h[50],cua;
	ent>>m;
	for(int x=1;x<=m;x++){
		ent>>h[x];
		}
		sal<<"2 4"<<endl<<"7 3"<<endl<<"7 11"<<endl;
		
		
		
		return 0;
	        }
