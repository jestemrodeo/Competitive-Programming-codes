#include <bits/stdc++.h>
using namespace std;
int main (){
	ifstream ent("pista.in");
	ofstream sal("pista.out");
	int m,h[50],a,b,c,d,e,f,g,v,i,j,k,l,cua,n;
	ent>>m;
	for(int x=1;x<=m;x++){
		ent>>a;
		ent>>b;
		ent>>c;
		ent>>d;
		ent>>e;
		ent>>f;
		ent>>g;
		ent>>v;
		ent>>i;
		ent>>j;
		ent>>k;
		ent>>l;
		ent>>m;
		ent>>n;
		}
		if(c==k){
			cua++;
		}
		sal<<cua<<endl;
		
		
		
		
		return 0;
	        }
