#include <bits/stdc++.h>
using namespace std;
int main (){
	ifstream ent("pista.in");
	ofstream sal("pista.out");
	int m,h[50],cua;
	ent>>m;
	for(int x=1;x<=m;x++){
		ent>>h[x];//variable en donde se guarda la altura =h.
		}
		if(h.length()[3]==h.length()[11]){
			cua++;
		}
		if(h.length()[4]==h.length()[10]){
			cua++;
		}
		if(h.length()[5]==h.length()[9]){
			cua++;
		}
		if(h.length()[6]==h.length()[9]){
			cua++;
		}
		sal<<cua<<endl;
	   
																															
		
		
		
		return 0;
	        }
