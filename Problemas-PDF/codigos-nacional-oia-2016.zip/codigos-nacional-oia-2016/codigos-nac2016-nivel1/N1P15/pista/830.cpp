
#include <iostream>

int main(int argc, char **argv)
{
	int M=1,C,h,i,ce,cpl,ei,ef;
	FILE *ent,*sal;
	char dent[]="pista.in";
	char dsal[]="pista.out";
	ent=fopen(dent,"rt");
	sal=fopen(dsal,"wt");
	for(i=0;i<M;i++);
	{
		if(h<M==0);
		ce[M]=ce+1;
		h[M]=
			
			if();
			cpl[C]=cpl+i;
			ei[C]=ei+i;
			ef[C]=ef+i;
	}
	fclose (ent);
	fprintf(sal,"%d	",cpl);
	fprintf(sal,"%d	",ei);
	fprintf(sal,"%d	",ef);
	fclose(sal);
	getchar ();
	return 0;
}

