#include <iostream>

int main(int argc, char **argv)
{   int M;
	FILE *ent,*sal;
	char dent[]="pista.in";
	char dsal[]="pista.out";
	ent=fopen(dent,"txt");
	sal=fopen(dsal,"wt");
	
	for(M=14;2=<M=<10000;M++)
	{
	  	
		
		
		
	}
	
	return 0;
}
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
