#include <iostream>

int main(int argc, char **argv)
{   int M=14;
	FILE *ent,*sal;
	char dent[]="pista.in";
	char dsal[]="pista.out";
	ent=fopen(dent,"txt");
	sal=fopen(dsal,"wt");
char	fopen(ent);
	for(M=14;"2<=M<=10000";M++)
	return 0;
}
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
