
#include <iostream>

int main(int argc, char **argv)
{
	int M,max=10000,vsec[max],i;
	
	FILE *ent,*sal;
	char ent=dent[]="pista.in";
	char sal=dsal[]="pista.out";
	ent  fopen=(dent,"rt");
	sal  fopen=(dsal,"wt");
	
	 fscanf(ent,"%d ",&M);
     {
	 for(i=0; M <= 10000;i++)
	  {
		 if(vsec[max]<=10000)
		 	M=M<=10000;
       }
       
	
	return 0;
	
}

