#include<bits/stdc++.h>
using namespace std;
ifstream ent;
ofstream sal;
int main () {
   ent.open("codigo.in");
   sal.open("codigo.out");
   int bas,Clave,lin;
  
   ent>>bas>>Clave;
   ent>>lin;
   string Texto[lin];
   ent>>Texto[lin];
   for(int i=0;i<=lin;i++){
	   
   }
   ent.close();
   sal.close();
}

