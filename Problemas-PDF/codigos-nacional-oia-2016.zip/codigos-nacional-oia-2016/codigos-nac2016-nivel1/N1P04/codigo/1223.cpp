#include <bits/stdc++.h>
using namespace std;
int main(){

char i;
cin>>i;
cout<<i+3;
}
