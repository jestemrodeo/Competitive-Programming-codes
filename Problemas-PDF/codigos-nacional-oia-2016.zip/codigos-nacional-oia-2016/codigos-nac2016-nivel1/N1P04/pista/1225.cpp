#include <bits/stdc++.h>
using namespace std;
int main(){

freopen("pista.in","r",stdin);
freopen("pista.out","w",stdout);

int M,C;
cin>>M;
int h[M];
    for(int i=M;i>0;i--){
        cin>>h[i];


        }
    }
