#include <iostream>

int main(int argc, char **argv)
{
    FILE *entrada, ;   
    char dent


	
	return 0;
}
