#include <string>

using namespace std;

string desvela(string captado, string conocido)
{
    captado = "s";
    return captado;
}
