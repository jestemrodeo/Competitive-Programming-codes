#include <string>
#include <cstdio>
#include <iostream>
#include <cmath>
#define pii pair<int,int>
using namespace std;

string desvela(string captado, string conocido)
{
	/*//clave
	char prev;
	pii val;
	bool terminar=false;
	for(int i=0;i<conocido.size();i++)
	{
		if(i==0)
		{
			if(conocido[0]=='*'||conocido[0]==' ')
				prev='0';
			else
				prev=conocido[0];
			continue;
		}
			
	}
	if(terminar)
		break;
	cout<<val.first<<" "<<val.second<<endl;
	getchar();*/
    return captado;
}
