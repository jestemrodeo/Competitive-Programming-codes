#include <string>
#include <iostream>
#include <sstream>


using namespace std;

string encriptado(int clave, int N, string texto)
{
    //Muestra
    string encriptado="YO HE LOGRADO ENCENDER UNA CERILLA";
    long clave;
    int n;
    n=23;
    clave=2;
    cout << n << " " << clave << endl;
    cout << encriptado << endl;
    //calculos
    texto="ARJHNRIUCGQHPFGQFHTXPPDEHTLNOC";

    return texto;
}
