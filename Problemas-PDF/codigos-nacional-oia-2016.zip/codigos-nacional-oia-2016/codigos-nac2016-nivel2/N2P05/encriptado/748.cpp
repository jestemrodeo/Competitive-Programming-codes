#include <string>
#include <iostream>
#include <sstream>


using namespace std;

string encriptado(int clave, int N, string texto)
{
    string encriptado="YO HE LOGRADO ENCENDER UNA CERILLA";
    string texto="ARJHNRIUCGQHPFGQFHTXPPDEHTLNOC";
    long Clave=2;
    long N=23;
    cout << Clave << " " << N << endl;
    cout <<  encriptado << endl;
    return texto;
}
