#include <string>
#include <iostream>
#include <sstream>


using namespace std;

string encriptado(int clave, int N, string texto)
{
    string encriptado[100]="YO HE LOGRADO ENCENDER UNA CERILLA";
    cout << "2 23" << endl;
    cout << encriptado << endl;
    texto="ARJHNRIUCGQHPFGQFHTXPPDEHTLNOC";
    for (int i=1; i=29; i++) {
        if ((encriptado[i] / 2)==0)  {
            cout << "par" << endl;
        }else{
            cout << "impar" << endl;
        }
    }
    return texto;
}
