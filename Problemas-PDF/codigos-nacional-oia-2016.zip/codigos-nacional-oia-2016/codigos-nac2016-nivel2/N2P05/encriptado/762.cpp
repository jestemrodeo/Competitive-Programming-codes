#include <string>
#include <iostream>
#include <sstream>


using namespace std;

string encriptado(int clave, int N, string texto)
{
    //Muestra
    string encriptado="YO HE LOGRADO ENCENDER UNA CERILLA";
    int n=23;
    int clave=2;
    cout << clave << " " << n << endl;
    cout << encriptado << endl;
    //calculos
    texto="ARJHNRIUCGQHPFGQFHTXPPDEHTLNOC";

    return texto;
}
