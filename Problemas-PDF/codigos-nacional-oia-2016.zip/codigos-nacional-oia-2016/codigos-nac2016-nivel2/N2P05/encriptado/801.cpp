#include <string>
#include <iostream>
#include <sstream>


using namespace std;

string encriptado(int clave, int N, string texto)
{
    string encriptado="YO HE LOGRADO ENCENDER UNA CERILLA";
    long clave=23;
    long n=2
    cout << "2 23" << endl;
    cout << encriptado << endl;
    texto="ARJHNRIUCGQHPFGQFHTXPPDEHTLNOC";

    return texto;
}
