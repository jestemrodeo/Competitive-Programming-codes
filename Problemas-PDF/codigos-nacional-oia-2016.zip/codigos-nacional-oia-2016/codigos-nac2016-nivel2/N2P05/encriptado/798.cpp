#include <string>

#include <sstream>


using namespace std;

string encriptado(int clave, int N, string texto)
{
    //Muestra
    string encriptado="YO HE LOGRADO ENCENDER UNA CERILLA";
    long clave=23;
    long n=2
    cout << n << " " << clave << endl;
    cout << encriptado << endl;
    //calculos
    texto="ARJHNRIUCGQHPFGQFHTXPPDEHTLNOC";

    return texto;
}
