#include <vector>
#include <iostream>


using namespace std;

int toldos(vector<int> feriantes, vector<int> costos)
{

    int P,F; cin >> P >> F;
    for (int i=0; i<F; i++) {
        feriantes[i];
        cin >> feriantes[i];
    }
    for (int i=0; i<P; i++) {
        costos[i];
        cin >> costos[i];
    }
    cout << "Con " << P << " puestos y " << F << " feriantes cuesta " <<  endl;
    return 115;
}

