#include<iostream>
#include<vector>
#include<string.h>
using namespace std;

int main()
{
    int clave=23;
    int N=2;
    string texto;
    string textoencriptado;



    cout<<"Ingrese El Texto A Encriptar Por Favor."<<endl;
    cin>>texto;

    cout<<"El Texto Ingresado A Encriptar Es: "<<texto<<endl;
    cout<<"El Texto Encriptado Es: "<<textoencriptado<<endl;




    cin.get();
    return 0;
}
