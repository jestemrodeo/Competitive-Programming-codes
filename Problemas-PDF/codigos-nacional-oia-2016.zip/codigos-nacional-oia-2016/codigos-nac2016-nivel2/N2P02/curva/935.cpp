#include<iostream>
#include<vector>
#include<string>

string curva(barrio, k, pista<x<int>)
{

int m, h, x;

barrio.resize[m];
pista.resize[x];



}
