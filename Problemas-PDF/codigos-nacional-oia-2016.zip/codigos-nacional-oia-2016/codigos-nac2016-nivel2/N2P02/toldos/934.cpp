#include<iostream>
#include<vector>
#include"studio.h"
#include<string>

string toldos(feriantes[F], costos[P])
{

int P, F;
(1<=P<=4000);
(0<=F<=1500);

FILE * ENTRADA;
FILE * SALIDA;

fopen=(ENTRADA);
fopen=("encriptado.in");
fscanf=("encriptado.in","r");
fscanf=("encriptado.in","w");
fclose=(ENTRADA);



fprintf=("Con P")
