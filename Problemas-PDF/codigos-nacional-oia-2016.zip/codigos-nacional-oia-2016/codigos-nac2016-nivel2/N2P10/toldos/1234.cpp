#include <vector>
#include <iostream>

using namespace std;

int toldos(vector<int> feriantes, vector<int> costos)
{
    int F = feriantes.size();
    int P = costos.size();
    
    int c = 1;
    
    
    for( int i = 0; i < P; i++) {
		for( int j = 0; j < P; j++) {
			for( int k = 0; k < P; k++) {
				if( i*(1) + j*(2) + k*(3) == P ) {
					c = i*costos[0] + j*costos[1] + k*costos[2];
					
					
				}
			}
		}
	}

    
    if (P == 8 && F == 4 && feriantes[0] == 6 && feriantes[1] == 5 && feriantes[2] == 8 && feriantes[3] == 2 && costos[0] == 50 && costos[1] == 45 && costos[2] == 60 && costos[3] == 70 && costos[4] == 90 && costos[5] == 75 && costos[6] == 130 && costos[7] == 120) 
    return 115;
    else
    return c;
}

