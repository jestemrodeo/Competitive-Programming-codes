#include <string>

using namespace std;

int  dictado( string palabra )
{
    // Aqui se debe completar con una solucion al problema
}
