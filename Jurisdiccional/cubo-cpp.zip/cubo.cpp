#include <string>
#include <vector>

using namespace std;

int cubo(vector<vector<vector<int>>> &v) {
    // AQUI SE DEBE IMPLEMENTAR LA SOLUCION
}
