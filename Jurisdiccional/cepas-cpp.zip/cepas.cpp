#include <string>
#include <vector>

using namespace std;

void inicializar() {
    // AQUI SE DEBE IMPLEMENTAR LA SOLUCION
}

void mutacion(int madre) {
    // AQUI SE DEBE IMPLEMENTAR LA SOLUCION
}

int madres() {
    // AQUI SE DEBE IMPLEMENTAR LA SOLUCION
}

int maxgen() {
    // AQUI SE DEBE IMPLEMENTAR LA SOLUCION
}

int originaria(vector<int> &cepas) {
    // AQUI SE DEBE IMPLEMENTAR LA SOLUCION
}
